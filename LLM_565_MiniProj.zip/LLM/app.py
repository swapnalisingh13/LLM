import streamlit as st
from streamlit_option_menu import option_menu
from dotenv import load_dotenv
import os

from Models.sdf2 import display_SDF
from Models.extract import display_Img_Text

load_dotenv()
HUGGINGFACE_API_KEY = os.getenv('HUGGINGFACE_API_KEY')
#HUGGINGFACE_API_KEY = st.secrets['HUGGINGFACE_API_KEY']


st.set_page_config(
        page_title="",
)

# Sidebar
with st.sidebar:
    # Create the options menu
    selected = option_menu(menu_title="ImageGo",
                           options=["Txt-To-Img","Img-To-Txt",],
                           icons=["box", "box","box"],
                           menu_icon="boxes",
                           default_index=0
                           )
    
if selected == "Txt-To-Img":
    display_SDF(HUGGINGFACE_API_KEY)

elif selected == "Img-To-Txt":
    display_Img_Text(HUGGINGFACE_API_KEY)