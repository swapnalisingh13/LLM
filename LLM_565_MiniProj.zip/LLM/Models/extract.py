import streamlit as st
import requests
import io
from PIL import Image

# Updated function without caching
def extract_text_from_image(token, _image):
    API_URL = "https://api-inference.huggingface.co/models/microsoft/trocr-base-handwritten"
    headers = {"Authorization": f"Bearer {token}"}

    # Convert the image to bytes
    buffered = io.BytesIO()
    _image.save(buffered, format="PNG")
    image_bytes = buffered.getvalue()

    response = requests.post(API_URL, headers=headers, data=image_bytes)
    
    # Check if the request was successful
    if response.status_code == 200:
        try:
            response_text = response.json()
            # Debug: print the response to understand its structure
            print("Response JSON:", response_text)

            # Try to extract the text from the response
            return response_text.get("generated_text", "No text extracted.")
        except ValueError as e:
            # Handle cases where JSON decoding fails
            print("JSON decoding failed:", e)
            return "Failed to decode JSON response."
    else:
        # Handle unsuccessful request
        print(f"Request failed with status code {response.status_code}")
        return f"Request failed with status code {response.status_code}: {response.text}"


def display_Img_Text(token):
    st.markdown("<h1 style='text-align:center;'>Image-to-Text Extraction</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align:center;'>Upload an image containing text, and the model will extract the text for you.</p>", unsafe_allow_html=True)

    with st.sidebar:
        st.subheader("Usage Manual")
        st.markdown("""
            <ul>
                <li>Upload an image containing handwritten or printed text.</li>
                <li>The model will extract the text from the image and display it on the screen.</li>
                <li>If the extraction fails, ensure the image quality is good and the text is clear.</li>
            </ul>
        """, unsafe_allow_html=True)
        st.success("You are good to go!")

    uploaded_image = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg"])

    if uploaded_image:
        image = Image.open(uploaded_image)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        if st.button("Extract Text"):
            with st.spinner("Extracting text from the image..."):
                extracted_text = extract_text_from_image(token, image)

            st.markdown("### Extracted Text:")
            st.write(extracted_text)

# Run the Streamlit app
if __name__ == "__main__":
    token = st.text_input("Enter your Hugging Face API token")
    if token:
        display_Img_Text(token)
