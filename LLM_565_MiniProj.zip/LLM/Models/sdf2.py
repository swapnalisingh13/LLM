import streamlit as st
import requests
import io
from PIL import Image

@st.cache_data
def SDXL(token, inputs, guide_scale, inference_steps, Negative):
    API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
    headers = {"Authorization": f"Bearer {token}"}

    payload = {
        "inputs": inputs,
        "guidance_scale": guide_scale,
        "num_inference_steps": inference_steps,
        "negative_prompt": Negative
    }
    
    response = requests.post(API_URL, headers=headers, json=payload)
    image_bytes = response.content

    return image_bytes

def display_SDF(token):
    st.markdown("<h1 style='text-align:center;'>Stable Diffusion XL</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align:center;'>You can download the image with right click > save image</p>", unsafe_allow_html=True)

    with st.sidebar:
        st.title("Tuning Model")
        st.session_state.GS_val = st.slider("Select Guidance Scale", key="slider1", min_value=0.1, max_value=10.0, value=7.5, step=0.1, help="Controls the strength of the prompt's influence on the generated image.")
        st.write('Guidance scale:', st.session_state.GS_val)

        st.session_state.inference_steps_val = st.slider("Select Inference Steps", key="slider2", min_value=50, max_value=200, value=50, step=1, help="Number of inference steps for image generation")
        st.write('Inference Steps:', st.session_state.inference_steps_val)

        st.session_state.Negative = st.text_input("Enter Negative Prompt", help="Elements you don't want to appear in the image")

        st.subheader("Usage Manual")
        st.markdown("""
            <ul>
                <li>Guidance scale: Determines how strongly your prompt influences the image generation. Higher values mean stronger adherence to the prompt.</li>
                <li>Negative Prompt: Specifies elements or features you want to exclude from the generated image.</li>
                <li>Inference Steps: Determines the number of steps the model takes to generate an image, with more steps generally leading to higher quality. </li>
                <li>If the image generation fails, try modifying the prompt or reducing the guidance scale.</li>
            </ul>
        """, unsafe_allow_html=True)
        st.success("You are good to go!")

    if "messages" not in st.session_state:
        st.session_state["messages"] = [
            {"role": "assistant", "content": "What kind of image do you need me to generate? (example: running cat)"}]

    # Display previous prompts and results
    for message in st.session_state.messages:
        st.chat_message(message["role"]).write(message["content"])
        if "image" in message:
            st.chat_message("assistant").image(message["image"], caption=message["prompt"], use_column_width=True)

    # Prompt Logic
    prompt = st.chat_input("Enter your prompt:")

    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)

        try:
            # Call the SDXL function with updated parameters
            image_bytes = SDXL(token, prompt, st.session_state.GS_val, st.session_state.inference_steps_val, st.session_state.Negative)

            # Open the image using PIL
            image = Image.open(io.BytesIO(image_bytes))
            msg = f'Here is your image related to "{prompt}"'

            # Show the result
            st.session_state.messages.append({"role": "assistant", "content": msg, "prompt": prompt, "image": image})
            st.chat_message("assistant").write(msg)
            st.chat_message("assistant").image(image, caption=prompt, use_column_width=True)
    
        except Exception as e:
            st.chat_message("assistant").write("Our server is at max capacity. Try again later!")
